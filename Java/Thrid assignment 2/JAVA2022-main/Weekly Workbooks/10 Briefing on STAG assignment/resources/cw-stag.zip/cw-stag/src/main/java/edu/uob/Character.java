package edu.uob;

public class Character extends GameEntity {
    boolean isUsing = false;
    public Character(String name, String description){
        super(name, description);
    }
}
