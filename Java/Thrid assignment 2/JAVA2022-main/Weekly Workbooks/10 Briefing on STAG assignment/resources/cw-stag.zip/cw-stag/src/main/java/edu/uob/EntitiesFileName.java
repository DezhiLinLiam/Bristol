package edu.uob;

public class EntitiesFileName {
    String name;

    public EntitiesFileName(String name){
        this.name = name;
    }

    public String getFileName(){
        return name;
    }
}
