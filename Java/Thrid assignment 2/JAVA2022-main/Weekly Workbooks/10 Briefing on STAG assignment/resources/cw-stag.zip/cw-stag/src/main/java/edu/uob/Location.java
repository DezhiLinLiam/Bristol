package edu.uob;

public class Location extends GameEntity{
    
    public Location(String name, String description){
        super(name, description);
    }
}
